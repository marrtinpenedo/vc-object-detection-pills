"""Recipes and dependency graphs for the two independent EXP-009 follow-ups."""
SMOKE = "smoke-photometric"
RUNTIME_PLAN = {"B": "configs/campaign/exp-009-a.json", "D": "configs/campaign/exp-008.json"}


def recipe(plan, condition):
    """Add only the intervention (B) or change only the seed (D)."""
    base = plan["reference"]["arms"][condition["reference"]]["config"]
    if plan["phase"] == "B":
        return {**base, "photometric": plan["photometric"]}
    return {**base, "seed": condition["seed"]}


def smoke_recipe(plan):
    return {**recipe(plan, plan["conditions"][-1]), "epochs": 3, "freeze_backbone_epochs": 1}


def graph(plan):
    backend, = plan["packages"]
    conditions = plan["conditions"]
    preflight = f"preflight-{backend}"
    probes = [conditions[0]["name"]]
    if plan["phase"] == "B":
        probes += [SMOKE]
    nodes = {preflight: {"stage": "preflight", "backend": backend, "requires": None, "probes": probes}}
    for condition in conditions:
        name = condition["name"]
        nodes[f"train-{name}"] = {"stage": "train", "backend": backend, "condition": name, "requires": preflight}
        nodes[f"eval-{name}"] = {"stage": "eval", "backend": backend, "condition": name, "requires": f"train-{name}"}
    return nodes


def verify_plan(plan, historical, historical_recipe):
    fixed = ("dataset", "dataset_relpath", "dataset_manifest_sha256", "valid_coco_sha256",
             "evaluation", "weights", "packages", "seed")
    if not all(plan[key] == historical[key] for key in fixed):
        raise ValueError("El protocolo o las entradas difieren de la campaña original")
    phase = plan["phase"]
    references = plan["reference"]["arms"]
    old_arms = {row["name"]: row for row in historical["conditions"]}
    for name, reference in references.items():
        if reference["condition"] != old_arms[name] or reference["config"] != historical_recipe(historical, old_arms[name]):
            raise ValueError(f"Receta de referencia incompatible: {name}")
    if phase == "B":
        expected_names = [f"f{freeze:03d}-{geom}" for freeze in (0, 80) for geom in ("control", "geom")]
        if (list(references) != expected_names
                or any(plan[k] != historical[k] for k in ("geometric", "mosaic_probability"))
                or plan["photometric"] != {"probability": .5, "brightness": .1, "contrast": .1}):
            raise ValueError("El factorial B requiere los cuatro controles A y la política EXP-002")
        expected = [{**old_arms[name], "name": name + "-photo", "reference": name, "seed": 2026}
                    for name in expected_names]
    else:
        if phase != "D" or set(references) != {"e100-f000"}:
            raise ValueError("D requiere el control de 100 épocas de EXP-008")
        expected = [{**old_arms["e100-f000"], "name": f"e100-f000-s{seed}",
                     "reference": "e100-f000", "seed": seed} for seed in (2027, 2028)]
    if plan["conditions"] != expected:
        raise ValueError("Matriz de entrenamientos incompatible")
